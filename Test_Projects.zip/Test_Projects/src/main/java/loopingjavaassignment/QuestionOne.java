package loopingjavaassignment;

import java.util.Scanner;

public class QuestionOne {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter the number:");
		int value=s.nextInt();
		if(value>=0) {
			System.out.println("number is positive");
			
		}else {
			System.out.println("number is negative");
		}
		

	}

}
