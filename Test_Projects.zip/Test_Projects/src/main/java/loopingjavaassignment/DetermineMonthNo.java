package loopingjavaassignment;

import java.util.Scanner;

public class DetermineMonthNo {

	public static void main(String[] args) {
		Scanner sd=new Scanner(System.in);
		System.out.print("Enter a value of month:");
		int month=sd.nextInt();
		
		String stringMonth="";
		switch(month) {
		case 1: stringMonth="1-januvary";
		break;
		case 2: stringMonth="2-feb";
		break;
		case 3: stringMonth="3-march";
		break;
		case 4: stringMonth="4-april";
		break;
		case 5: stringMonth="5-may";
		break;
		case 6: stringMonth="6-june";
		break;
		case 7: stringMonth="7-july";
		break;
		case 8: stringMonth="8-aug";
		break;
		case 9: stringMonth="9-sept";
		break;
		case 10: stringMonth="10-oct";
		break;
		case 11: stringMonth="11-nov";
		break;
		case 12: stringMonth="12-dec";
		break;
		default:
			System.out.println("Invalid input");
		}
		System.out.println(stringMonth);

	}

}
