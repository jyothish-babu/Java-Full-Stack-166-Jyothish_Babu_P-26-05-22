package loopingjavaassignment;

import java.util.Scanner;

public class QuestionTwo {

	public static void main(String[] args) {
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter the first number:");
		int value1=sc1.nextInt();
		
		System.out.println("Enter the second number:");
		int value2=sc1.nextInt();
		
		if(value1==value2) {
			System.out.println("Given no is equal");
			}else {
				System.out.println("Given no is not equal");
			}
		

	}

}
