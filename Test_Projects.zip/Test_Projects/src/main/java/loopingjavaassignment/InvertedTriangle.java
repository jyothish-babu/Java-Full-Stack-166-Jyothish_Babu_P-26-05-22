package loopingjavaassignment;

public class InvertedTriangle {

	public static void main(String[] args) {
		int value=6;
		for(int i=1;i<=value;i++) {
			for(int j=value;j>=i;j--) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
