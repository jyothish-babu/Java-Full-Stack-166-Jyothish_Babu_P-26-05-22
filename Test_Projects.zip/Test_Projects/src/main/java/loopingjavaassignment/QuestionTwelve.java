package loopingjavaassignment;

import java.util.Scanner;

public class QuestionTwelve {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a digit:");
		int value=sc.nextInt();
		int limit=10;
		
		for(int i=1;i<=limit;i++) {
			int sum=i*value;
			System.out.println(i+"*"+value+"="+sum);
			
		}

	}

}
