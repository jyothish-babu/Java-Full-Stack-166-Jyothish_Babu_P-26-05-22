package loopingjavaassignment;

import java.util.Scanner;

public class QuestionThirteen {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a the first sdigit:");
		int val1=sc.nextInt();
		System.out.print("Enter the Second digit:");
		int val2=sc.nextInt();
		
		int temp;
		
		System.out.println("before swaping");
		System.out.println("valueOne is:"+val1);
		System.out.println("valueTwo is:"+val2);
		
		temp=val1;
		val1=val2;
		val2=temp;
		
		System.out.println("After swaping");
		System.out.println("valueOne is:"+val1);
		System.out.println("valueTwo is:"+val2);

	}

}
