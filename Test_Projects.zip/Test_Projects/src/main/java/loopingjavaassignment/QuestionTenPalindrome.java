package loopingjavaassignment;

import java.util.Scanner;

public class QuestionTenPalindrome {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number:");
		int value=sc.nextInt();
		
		int rev=0,rem,temp;
		

		temp=value;
		while(value>0) {
			rem=value%10;
			rev=(rev*10)+rem;
			value=value/10;
			
		}
		
		
		
		if(temp==rev) {
			System.out.println("entered num is palindrome");
			}
			else { 
				System.out.println("entered num is not a palindrome");
		}

	}

}
