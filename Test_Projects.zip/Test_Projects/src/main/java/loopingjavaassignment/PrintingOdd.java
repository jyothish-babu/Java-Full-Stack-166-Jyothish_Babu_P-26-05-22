package loopingjavaassignment;

public class PrintingOdd {

	public static void main(String[] args) {
		int n1=1;
		int n2=50;
		for(int i=n1;i<=n2;i++) {
			if(i%2!=0) {
				System.out.println(i);
			}
		}

	}

}
