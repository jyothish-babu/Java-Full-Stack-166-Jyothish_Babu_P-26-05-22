package loopingjavaassignment;

import java.util.Scanner;

public class QuestionFifteen {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a number:");
		int value=sc.nextInt();
		int temp,rem,count=0;
		double sum = 0;
		temp=value;
		while(value!=0) {
			count++;
			value=value/10;
			
		}
		value=temp;
		while(value!=0) {
			rem=value%10;
			sum=sum+Math.pow(rem,count);
			value=value/10;
		}
		
		if(temp==sum) {
			System.out.println(temp+" ia an armstrong");
		}else {
			System.out.println(temp+" is not an armstrong");
		}
		
	}

}
