package loopingjavaassignment;

import java.util.Scanner;

public class QuestionFourteen {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter days:");
		int num=sc.nextInt();
		
		int days= num%30;
		int month=num/30;
		System.out.println(num+" days have "+month+" months and "+days+" days");

	}

}
