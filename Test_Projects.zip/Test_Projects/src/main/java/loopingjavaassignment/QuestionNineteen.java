package loopingjavaassignment;

public class QuestionNineteen {

	public static void main(String[] args) {
		int count=0;
		int n=4;
		for(int i=1;i<=n;i++){
			
			for(int j=1;j<=i;j++) {

				System.out.print(count+" ");
				if(count==0) {
					count=1;
				}else { 
					count=0;
				}
			}
			count=0;
			System.out.println();
			
		}


	}

}
