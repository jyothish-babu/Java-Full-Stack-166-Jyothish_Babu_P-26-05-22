package loopingjavaassignment;

public class PrintOddNum {

	public static void main(String[] args) {
		

	}

}
