package loopingjavaassignment;

import java.util.Scanner;

public class QuestionSeventeen {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter anumber:");
		int input=sc.nextInt();
		int n=input;
		int evenCount=0,evenSum=0,oddCount=0,oddSum=0;
		while(n>0) {
			if(n%2==0) {
				evenCount++;
				evenSum=evenSum+n;
			}else {
				oddCount++;
				oddSum=oddSum+n;
			}
			n--;
		}
		int avgEven,avgOdd;
		avgEven=evenSum/evenCount;
		avgOdd=oddSum/oddCount;
		System.out.println("avarage of evenNumbers in "+input+"="+avgEven);
		System.out.println("average of oddNumbers in "+input+"="+avgOdd);
		

	}

}
