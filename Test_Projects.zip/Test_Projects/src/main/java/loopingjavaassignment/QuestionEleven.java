package loopingjavaassignment;

public class QuestionEleven {

	public static void main(String[] args) {
		int sum=0,count=0;
		int value=100;
		int value2=200;
		
		for(int i=value+1;i<value2;i++) {
			if(i%7==0) {
				sum=sum+i;
				count++;
			}
			
		}
		System.out.println(sum);
		System.out.println(count);
		

	}

}
