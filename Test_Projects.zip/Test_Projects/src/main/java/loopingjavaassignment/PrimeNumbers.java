package loopingjavaassignment;

import java.util.Scanner;

public class PrimeNumbers {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the first number:");
		int value1=sc.nextInt();
		System.out.print("Enter the second number:");
		int value2=sc.nextInt();

		
		for(int i=value1;i<=value2;i++) {
		boolean pp=false;
		for(int j=2;j<=i/2;j++) {
			if(i%j==0) {
				pp=true;
				break;
			}
			
		}
		if(pp==true) {
			continue;
		}
		else {
			System.out.println(i);
		}
		}
		
	}
}