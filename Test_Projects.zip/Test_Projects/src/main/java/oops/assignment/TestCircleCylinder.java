package oops.assignment;

public class TestCircleCylinder {

	public static void main(String[] args) {
		CircleCylinder cc=new CircleCylinder(12.3,5.8);
		cc.getRadious();
	    System.out.println("area of a circle is: "+cc.getArea());
	    cc.getHeight();
	    System.out.println("volume of a cylinder is: "+cc.getVolume());

	}

}
