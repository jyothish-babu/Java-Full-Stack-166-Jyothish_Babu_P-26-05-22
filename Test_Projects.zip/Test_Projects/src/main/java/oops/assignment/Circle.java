package oops.assignment;

public class Circle {
	private double radious;
	//private String colour;
	public Circle(double radious) {
		super();
		this.radious = radious;
		
	}


	public void getRadious() {
		System.out.println("Radious is:"+radious);

	}
	
	public double getArea() {
		
		double data=radious*radious*3.14;
		return data;
		
	}

}
