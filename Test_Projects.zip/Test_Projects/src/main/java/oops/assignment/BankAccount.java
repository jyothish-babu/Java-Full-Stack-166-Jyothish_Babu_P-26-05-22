package oops.assignment;

public class BankAccount {
	private int accNo;
	private double balance=0.0;
	public int getAccNo() {
		return accNo;
	}
	
	public BankAccount(int accNo, double balance) {
		super();
		this.accNo = accNo;
		this.balance = balance;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public double getBalance() {
		return balance;
	}
	
	public void credit(double amount) {
		balance=balance+amount;
	}
	public void debit(double amount) {
		
		if(balance<amount) {
			System.out.println("insufficient balance "+balance);
		}
		else {
			balance=balance-amount;
		}
	}
	@Override
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", balance=" + balance + "]";
	}

}
