package oops.assignment;

public class CircleCylinder extends Circle{
	private double height;
	public CircleCylinder(double radious,double height) {
		super(radious);
		this.height=height;
		
	}
	public void getHeight() {
		System.out.println("Height of the cylinder is:"+height);
	}
	
	public double getVolume() {
		double volume=super.getArea()*height;
		return volume;
	}

	
	
	

}
