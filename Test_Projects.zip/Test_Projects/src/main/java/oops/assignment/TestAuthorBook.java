package oops.assignment;

public class TestAuthorBook {

	public static void main(String[] args) {
		Author author=new Author("arun","arun@gmail.com",'m');
		Book b=new Book("java",author,2500.0,500);
		System.out.println(b);
		
		System.out.println(b.getAuthor().getName());
		b.setbName("python");
		System.out.println(b.getbName());
		
		System.out.println(b);

	}

}
