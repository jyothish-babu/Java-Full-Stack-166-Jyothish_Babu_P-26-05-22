package oops.assignment;

public class TextBankAccount {

	public static void main(String[] args) {
		BankAccount bc=new BankAccount(11223,2500.0);
		bc.credit(500);
		System.out.println(bc.getBalance());
		
		bc.debit(3500);
		
		bc.debit(2500);
		System.out.println(bc.getBalance());
		
		
		
		
		

	}

}
