package oops.assignment;

public class Book {
	
	private String bName;
	private Author author;
	private double price;
	private int inStock;
	
	public Book(String bName, Author author, double price, int inStock) {
		super();
		this.bName = bName;
		this.author = author;
		this.price = price;
		this.inStock = inStock;
	}

	public String getbName() {
		return bName;
	}

	public void setbName(String bName) {
		this.bName = bName;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getInStock() {
		return inStock;
	}

	public void setInStock(int inStock) {
		this.inStock = inStock;
	}

	@Override
	public String toString() {
		return "Book [bName=" + bName + ", author=" + author + ", price=" + price + ", inStock=" + inStock + "]";
	}
	
	

}
