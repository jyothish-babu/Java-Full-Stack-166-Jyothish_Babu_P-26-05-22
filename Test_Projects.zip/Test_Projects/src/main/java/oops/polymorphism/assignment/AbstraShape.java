package oops.polymorphism.assignment;

public abstract class AbstraShape {
	private String color;

	public AbstraShape(String color) {
		super();
		this.color = color;
	}

	@Override
	public String toString() {
		return "AbstraShape [color=" + color + "]";
	}
	abstract public double getArea();

}
