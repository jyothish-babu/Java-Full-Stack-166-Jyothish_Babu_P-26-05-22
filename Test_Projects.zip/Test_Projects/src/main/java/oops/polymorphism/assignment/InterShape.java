package oops.polymorphism.assignment;

public interface InterShape {
	double getArea();

}
