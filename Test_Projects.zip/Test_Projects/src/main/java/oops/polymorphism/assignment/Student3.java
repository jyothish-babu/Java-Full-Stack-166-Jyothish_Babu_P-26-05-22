package oops.polymorphism.assignment;

public class Student3 {               //29-04-2022 Constructor overloading
	int id;
	String name;
	int age;
	Student3(int i,String n){
		id=i;
		name=n;
		}
	Student3(int i,String n,int a){
		id=i;
		name=n;
		age=a;
		}
	
	void display() {
		System.out.println(id+""+name+""+age);
	}
	
	

}
