package oops.polymorphism.assignment;

public class AbstraRectangle extends AbstraShape{
	private int length;
	private int width;

	public AbstraRectangle(String color,int length,int width) {
		super(color);
		this.length=length;
		this.width=width;
		
	}
	@Override
	public double getArea() {
		
		return length*width;
	}
	@Override
	public String toString() {
		return "AbstraRectangle [length=" + length + ", width=" + width + "]";
	}
	

}
