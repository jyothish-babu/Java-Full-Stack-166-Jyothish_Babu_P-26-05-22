package oops.polymorphism.assignment;

public class ExmpPerson {
	private String name;
	private String address;
	
	public ExmpPerson(String name, String address) {
		super();
		this.name = name;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "ExmpPerson [name=" + name + ", address=" + address + "]";
	}
	
	
	

}
