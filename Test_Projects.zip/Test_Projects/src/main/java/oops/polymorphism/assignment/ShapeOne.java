package oops.polymorphism.assignment;

public class ShapeOne {
	private String color;

	public ShapeOne(String color) {
		super();
		this.color = color;
	}
	
	
	public double getArea() {
		return (Double) null;
	}


	@Override
	public String toString() {
		return "ShapeOne [color=" + color + "]";
	}
	
	

}
