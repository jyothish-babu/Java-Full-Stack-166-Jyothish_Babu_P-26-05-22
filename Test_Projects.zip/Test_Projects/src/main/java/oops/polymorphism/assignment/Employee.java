package oops.polymorphism.assignment;

public class Employee {
	int empid;
	String empName;
	float empSalary;
	void addemployee(int i,String n,float s) {
		empid=i;
		empName=n;
		empSalary=s;
		
	}
	void display() {
		System.out.println(empid);
		System.out.println(empName);
		System.out.println(empSalary);
	}

}
