package oops.polymorphism.assignment;

public class TestShapeOne {

	public static void main(String[] args) {
		ShapeOne r=new RectangleOne("red", 5, 6);
		System.out.println(r);
		System.out.println(r.getArea());
		
		r=new TriangleOne("blue", 4, 8);
		System.out.println(r);
		System.out.println(r.getArea());
		

	}

}
