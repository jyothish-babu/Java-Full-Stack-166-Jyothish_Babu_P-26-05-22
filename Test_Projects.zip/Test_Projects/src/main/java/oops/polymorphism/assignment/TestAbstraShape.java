package oops.polymorphism.assignment;

public class TestAbstraShape {

	public static void main(String[] args) {
		AbstraShape ab=new AbstraRectangle("swhite", 4, 6);
		System.out.println(ab);
		System.out.println(ab.getArea());
		
		AbstraShape ab1=new AbstraTriangle("Black", 8, 9);
		System.out.println(ab1);
		System.out.println(ab1.getArea());
		

	}

}
