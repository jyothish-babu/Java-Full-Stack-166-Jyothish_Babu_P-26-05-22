package oops.polymorphism.assignment;

public class StudentOne {
	int id;
	String name;
	
	void insert(int i,String n) {
		id=i;
		name=n;
	}
	void display() {
		System.out.println(id);
		System.out.println(name);
		
	}

}
