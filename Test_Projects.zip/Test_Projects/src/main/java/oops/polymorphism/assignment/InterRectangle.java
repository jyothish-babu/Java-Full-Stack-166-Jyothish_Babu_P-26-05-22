package oops.polymorphism.assignment;

public class InterRectangle implements InterShape {
	double base,height;

	public InterRectangle(double base, double height) {
		super();
		this.base = base;
		this.height = height;
	}



	@Override
	public String toString() {
		return "InterRectangle [base=" + base + ", height=" + height + "]";
	}



	@Override
	public double getArea() {
		
		return 0.5*base*height;
	}
	

}
