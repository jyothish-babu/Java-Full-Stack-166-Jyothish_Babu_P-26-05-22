package oops.polymorphism.assignment;

public class TestStudent2 {

	public static void main(String[] args) {
		Student2 s1=new Student2(101,"Akhil");
		Student2 s2=new Student2(102,"Akash");
		
		s1.display();
		s2.display();

	}

}
