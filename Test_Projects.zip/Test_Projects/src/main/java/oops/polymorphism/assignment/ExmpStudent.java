package oops.polymorphism.assignment;

import java.util.Arrays;

public class ExmpStudent extends ExmpPerson{
	private int numCourses=0;
	private String[] courses;
	private int[] grade;
	private static final int MAXCOURESE=30;

	public ExmpStudent(String name, String address) {
		super(name, address);
		
		courses=new String[MAXCOURESE];
		grade=new int[MAXCOURESE];
		
	}
	
	@Override
	public String toString() {
		return "ExmpStudent [numCourses=" + numCourses + ", courses=" + Arrays.toString(courses) + ", grade="
				+ Arrays.toString(grade) + "]";
	}
	
	public void addCourseGrade(String course,int gradee) {
		courses[numCourses]=course;
		grade[numCourses]=gradee;
		++numCourses;
		
	}
	public void printGrade() {
		for(int i=0;i<numCourses;i++) {
			System.out.print(courses[i]+" : "+grade[i]+",");
		}
		System.out.println();
	}
	public double getAvgGrade() {
		int sum=0;
		for(int i=0;i<numCourses;i++) {
			sum=sum+grade[i];
		}
		return sum/numCourses;
	}
	

//	public void addCourseGrade(String course,int grades) {
//		courses[numCourses]=course;
//		grade[numCourses]=grades;
//		++numCourses;
//		
//	}
	
	

}
