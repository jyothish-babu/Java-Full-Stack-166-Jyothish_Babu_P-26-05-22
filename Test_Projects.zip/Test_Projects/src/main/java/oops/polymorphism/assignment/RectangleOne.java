package oops.polymorphism.assignment;

public class RectangleOne extends ShapeOne  {
	private int length,width;

	public RectangleOne(String color,int length,int width) {
		super(color);
		this.length=length;
		this.width=width;
		
	}
	public double getArea() {
		return length*width;
	}
	@Override
	public String toString() {
		return "RectangleOne [length=" + length + ", width=" + width + "]";
	}
	
	
	
	

}
