package oops.polymorphism.assignment;

public class TestBall {

	public static void main(String[] args) {
		Ball b=new Ball(2.5,3.5);
		Ball b1=new Ball();
		Ball b2=new Ball();
		
		System.out.println(b);
		
		b1.setY(4.5);
		b1.setX(4.5);
		System.out.println(b1.toString());
		
		b1.setXY(5.5, 6.6);
		System.out.println(b1.toString());
		
		b1.move(7.7, 8.8);
		System.out.println(b1.toString());

	}

}
