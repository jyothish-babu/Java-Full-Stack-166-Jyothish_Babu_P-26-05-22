package oops.polymorphism.assignment;

public class TestStudent3 {

	public static void main(String[] args) {
		Student3 s1=new Student3(12,"Akhil");
		Student3 s2=new Student3(13,"Vishnu",25);
		s1.display();
		s2.display();

	}

}
