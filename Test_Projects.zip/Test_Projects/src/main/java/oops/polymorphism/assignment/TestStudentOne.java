package oops.polymorphism.assignment;

public class TestStudentOne {                        //28-04-2022

	public static void main(String[] args) {
		StudentOne s1=new StudentOne();
		StudentOne s2=new StudentOne();
		
		s1.id=10;                //print through reference variable
		s1.name="Jyothish";
		
		s2.id=11;
		s2.name="Ram";
		
		
		
		System.out.println(s1.id);
		System.out.println(s1.name);
		
		StudentOne s3=new StudentOne();   //print through method
		s3.insert(11,"JyothishBP");
		
		s3.display();
		s1.display();
	}
}
