package oops.polymorphism.assignment;

public class TestEmployee {
	public static void main(String[] args) {
		Employee emp1=new Employee();
		Employee emp2=new Employee();
		Employee emp3=new Employee();
		
		emp1.addemployee(1001, "Manu", 30000);
		emp1.display();
		
		emp2.addemployee(1002, "Rahul", 35000);
		emp2.display();
		
		emp3.addemployee(1001, "Veena", 45000);
		emp3.display();
	}

}
