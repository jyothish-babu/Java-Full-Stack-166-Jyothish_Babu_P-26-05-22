package oops.polymorphism.assignment;

public class TestInterShape {

	public static void main(String[] args) {
		InterShape sh=new InterRectangle(0.50, 0.25);
		System.out.println(sh);
		System.out.println(sh.getArea());
		
		sh=new InterTriangle(6, 6);
		System.out.println(sh);
		System.out.println(sh.getArea());
		

	}

}
