package oops.polymorphism.assignment;

public class TriangleOne extends ShapeOne{
	private int base,height;

	public TriangleOne(String color,int base,int height) {
		super(color);
		this.base=base;
		this.height=height;
		
	}
	public double getArea() {
		return 0.5*base*height;
	}
	@Override
	public String toString() {
		return "TriangleOne [base=" + base + ", height=" + height + "]";
	}
	

}
