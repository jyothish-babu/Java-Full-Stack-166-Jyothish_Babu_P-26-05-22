package oops.polymorphism.assignment;

public class InterTriangle implements InterShape {
	private int length,width;
	

	public InterTriangle(int length, int width) {
		super();
		this.length = length;
		this.width = width;
	}
	


	@Override
	public String toString() {
		return "InterTriangle [length=" + length + ", width=" + width + "]";
	}



	@Override
	public double getArea() {
		
		return length*width;
	}

}
