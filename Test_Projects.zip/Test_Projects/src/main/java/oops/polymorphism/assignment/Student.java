package oops.polymorphism.assignment;

public class Student {
	int id;
	String name;
    void read() {
		System.out.println("reading");
	}

	public static void main(String[] args) {
		Student s1=new Student();
		Student s2=new Student();
		System.out.println(s1.id);
		System.out.println(s1.name);
		

	}

}
