package oops.polymorphism.assignment;

public class TestExmpPerson {

	public static void main(String[] args) {
		//student
		ExmpStudent es=new ExmpStudent("Arun", "Kottayam");
		es.addCourseGrade("Ma1", 101);
		es.addCourseGrade("CH2", 102);
		es.addCourseGrade("PH", 103);
		
		es.printGrade();
		System.out.println(es.getAvgGrade());
		//teacher
		ExmpTeacher et=new ExmpTeacher("deepa", "vayanadu");
		String[] coursess= {"MA101","MA102","MA123"};
		//add
		for(String course :coursess) {
			if(et.addCourse(course)) {
				System.out.println(course+" is added");
			}else {
				System.out.println(course+" cannot be added");
			}
		}
		
		//remove
		for(String course:coursess) {
			if(et.removeCourse(course)) {
				System.out.println(course+" is removed");
			}
			else {
				System.out.println(course+" connot be removed");
			}
		}
//		et.addCourse("SC101");
//		et.addCourse("SC102");
//		System.out.println(et.toString());
//		
//		et.removeCourse("SC101");
//		System.out.println(et.toString());
		
		
		
		
		
		
	}

}
