package interfaces;

public class TestABC {

	public static void main(String[] args) {
		H exg=new H();
		exg.a();
		exg.b();
		exg.c();
		exg.e();

	}

}
