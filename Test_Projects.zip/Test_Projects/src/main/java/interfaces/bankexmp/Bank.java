package interfaces.bankexmp;

public interface Bank {
	float rateOfInterest();

}
