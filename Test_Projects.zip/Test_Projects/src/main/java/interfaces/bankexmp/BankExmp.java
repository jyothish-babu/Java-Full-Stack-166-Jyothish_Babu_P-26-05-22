package interfaces.bankexmp;

public class BankExmp {

	public static void main(String[] args) {
		Bank b=new SBI();
		
		System.out.println(b.rateOfInterest());
		
		b=new ICICI();
		System.out.println(b.rateOfInterest());
		

	}

}
