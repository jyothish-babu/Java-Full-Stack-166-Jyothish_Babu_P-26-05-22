package interfaces.bankexmp;

public class ICICI implements Bank{

	@Override
	public float rateOfInterest() {
		
		return 6.8f;
	}

}
