package interfaces.bankexmp;

public class SBI implements Bank {

	@Override
	public float rateOfInterest() {
		
		return 9.8f;
	}

}
