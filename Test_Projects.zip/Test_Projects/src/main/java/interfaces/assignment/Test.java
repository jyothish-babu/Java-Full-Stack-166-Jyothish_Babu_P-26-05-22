package interfaces.assignment;

public interface Test {
	
	public int square();

}
