package interfaces.assignment;

public class Arithmetic implements Test{

	@Override
	public int square() {
		
		return 5*3;
	}

	
	

}
