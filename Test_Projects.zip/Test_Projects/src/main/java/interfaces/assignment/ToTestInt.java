package interfaces.assignment;

public class ToTestInt {
	public static void main(String[] args) {
		Arithmetic obj=new Arithmetic();
		
		System.out.println(obj.square());
		
	}
	
	
	

}
