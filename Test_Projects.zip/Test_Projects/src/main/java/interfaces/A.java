package interfaces;

public interface A {
	void a();
	void b();
	void c();
	void e();

}
