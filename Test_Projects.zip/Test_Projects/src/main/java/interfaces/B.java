package interfaces;

public abstract class B implements A{
	public void e() {
		System.out.println("i am c");
	}

}
