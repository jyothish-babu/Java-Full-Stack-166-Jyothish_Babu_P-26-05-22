package interfaces;

public class H extends B {

	@Override
	public void a() {
		System.out.println("i an a");
		
	}

	@Override
	public void b() {
		System.out.println("i am b");
		
	}

	@Override
	public void c() {
		System.out.println("i am c");
		
	}
	

}
