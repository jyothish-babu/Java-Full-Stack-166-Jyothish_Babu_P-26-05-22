package example;

public class TypesVeriables {
	
	int a=10;//instance variable
	int b=5; //instance variable
	
	static String college="cek";
	
	int add() {
		int c=a+b;  // local variable
		System.out.println(college); //'college' is static variables so we can call with out using object
		return c;
	}

	public static void main(String[] args) {
		int value=2; //instance variable
		System.out.println(value);
		
		TypesVeriables obj = new TypesVeriables();
		System.out.println(obj.add());
		
		System.out.println(obj.b);
		
		System.out.println(college);
	}

}
