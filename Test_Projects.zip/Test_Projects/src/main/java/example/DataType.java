package example;

public class DataType {

	public static void main(String[] args) {
		boolean a =false;
		System.out.println(a);
		
		int b=222222552;
		System.out.println(b);
		
		long e=55555454l;
		System.out.println(e);
		
		float c=12.5f;
		System.out.println(c);
		
		short d=12222;
		System.out.println(d);
		
		char f='a';
		System.out.println(f);
		
		
		

	}

}
