package example;

public class Example {

	public static void main(String[] args) {
		System.out.println("Java");

	}

}
