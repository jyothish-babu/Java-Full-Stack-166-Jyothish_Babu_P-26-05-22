package example;

public class VariablesExample {

	public static void main(String[] args) {
		float f=10.5f; 
		
		// int a=f; compile time error when convert high to low
		int a=(int)f;
		System.out.println(f);
		System.out.println(a);
		
		

	}

}
