package inheriranceassignment;

public class TestCircle {

	public static void main(String[] args) {
		Circle obj=new Circle(2.0,"red");
		//Circle obj1=new Circle();
		
		obj.display();
		//obj1.display();
		
		System.out.println("area of circle is:"+obj.getarea());
		System.out.println("radious of circle is:"+obj.getradious());
		System.out.println(obj.toString());
		
	
		
		

	}

}
