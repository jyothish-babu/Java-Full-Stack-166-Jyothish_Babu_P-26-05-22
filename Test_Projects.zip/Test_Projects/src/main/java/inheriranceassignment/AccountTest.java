package inheriranceassignment;

public class AccountTest {

	public static void main(String[] args) {
		Account amount=new Account();
		amount.debit(150);
		System.out.println("Account balance is:"+amount.getBalance());
		
		amount.credit(50.0);
		System.out.println("Account balance is:"+amount.getBalance());
		

	}

}
