package inheriranceassignment;

public class Account {
	
	private double balance=200;
	
	
	public void credit(double amount) {
		balance=balance+amount;
		
	}
	
	public void debit(double withdraws) {
		if(withdraws<=balance) {
			balance=balance-withdraws;
		}
		else if(withdraws>balance) {
			System.out.println("Debit amount exceeded account balance");
		}
		
	}
	double getBalance() {
		return balance;
	}

}
