package inheriranceassignment;

public class TestDog {

	public static void main(String[] args) {
		Dog dg=new Dog("lab",3,"red");
        dg.display();
        
        dg.behaviour();

	}

}
