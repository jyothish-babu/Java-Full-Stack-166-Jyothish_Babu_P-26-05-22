package inheriranceassignment;

public class Dog {
	String breed;
	int age;
	String color;
	
	Dog(String breed,int age,String cocor){
		this.breed=breed;
		this.age=age;
		this.color=cocor;
	}
	void display() {
		System.out.println("breed:"+breed);
		System.out.println("age:"+age);
		System.out.println("color:"+color);
	}
	void behaviour() {
		System.out.println("bark");
		System.out.println("sleep");
	}

}
