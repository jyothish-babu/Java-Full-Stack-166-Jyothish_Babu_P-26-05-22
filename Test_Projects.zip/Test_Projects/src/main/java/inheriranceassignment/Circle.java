package inheriranceassignment;

public class Circle {
	double radious;
	String color;
	double area;
//	int dimeter;
	
	
	
	
	
//	public int getDimeter() {
//		return dimeter;
//	}
//
//	public void setDimeter(int dimeter) {
//		this.dimeter = dimeter;
//	}

	Circle(double radious,String color){
		this.radious=radious;
		this.color=color;
	}
	
	Circle(double area){
		this.area=area;
	}
	
	
	

	@Override
	public String toString() {
		return "Circle [radious=" + radious + ", color=" + color + ", area=" + area + "]";
	}

	void display() {
		
		System.out.println("radious:"+radious+" "+"colour:"+color+" "+"area:"+area);
	}
	double getradious() {
		return radious;
	}
	double getarea() {
		return 3.14*radious*radious;
	}
	

}
