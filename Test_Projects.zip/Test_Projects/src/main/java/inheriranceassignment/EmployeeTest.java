package inheriranceassignment;

public class EmployeeTest {

	public static void main(String[] args) {
		Employee e1=new Employee("akhil","s",22500.0);
		Employee e2=new Employee("vimal","n",30000.0);
		
		e1.display();
		//e2.display();
		
//		e1.setmSalary(-12.0);
//		System.out.println(e1.getmSalary());
		
		System.out.println("yearly Salary is:"+e1.yearlySalary());
		System.out.println("Yearly salary with 10% increment:"+e1.yearlySalareyincriment());
		
		System.out.println();
		
		e2.display();
		System.out.println("yearly Salary is:"+e2.yearlySalary());
		System.out.println("Yearly salary with 10% increment:"+e2.yearlySalareyincriment());
		
		

	}

}
