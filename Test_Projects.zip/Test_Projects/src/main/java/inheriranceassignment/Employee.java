package inheriranceassignment;

public class Employee {
	String firstName,lastName;
	double mSalary;
	
	public Employee(String firstName, String lastName, double salary) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mSalary = salary;
	}
	public Employee() {
		
	}
	void display() {
		if(mSalary<0) {
			this.mSalary=0.0;
		}
		System.out.println(firstName+" "+lastName+"\n"+"salary is:"+mSalary);
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getmSalary() {
		return mSalary;
	}

	public void setmSalary(double mSalary) {
		this.mSalary = mSalary;
		if(mSalary<0) {
			this.mSalary=0.0;
		}
	}
	public double yearlySalary() {
		
		mSalary=mSalary*12;
		return mSalary;
		
	}
	public double yearlySalareyincriment() {
		mSalary=mSalary+(mSalary*10)/100;
		return mSalary;
		
	}

	
}
