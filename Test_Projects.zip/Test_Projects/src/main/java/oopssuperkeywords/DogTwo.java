package oopssuperkeywords;

public class DogTwo extends AnimalTwo {
	DogTwo(){
		super();
		System.out.println("dogs");
	}

}
