package oopssuperkeywords;

public class AnimalTwo {
	AnimalTwo(){
		System.out.println("cute animal");
	}

}
