package oopssuperkeywords;

public class TestEmployee {

	public static void main(String[] args) {
		Employee e1=new Employee("Arun",102,25000);
		e1.display();
	}

}
