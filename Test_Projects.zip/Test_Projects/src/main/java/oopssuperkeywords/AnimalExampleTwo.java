package oopssuperkeywords;

public class AnimalExampleTwo extends AnimalExampleOne{
	int age;
	AnimalExampleTwo(int age){
		//super("name");
		this.age=age;
		
	}
	void display()
	{
		System.out.println(age);
		System.out.println(super.name);
		
	}


}
