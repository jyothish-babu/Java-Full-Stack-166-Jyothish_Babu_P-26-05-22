package oopssuperkeywords;

public class TestAnimalDog {

	public static void main(String[] args) {
		AnimalDog d=new AnimalDog();
		d.eating();

	}

}
