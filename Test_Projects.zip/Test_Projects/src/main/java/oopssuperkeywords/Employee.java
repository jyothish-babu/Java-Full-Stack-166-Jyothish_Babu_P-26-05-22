package oopssuperkeywords;

public class Employee extends Person{
	double salary;

	public Employee(String name, int id, double salary) {
		super(name, id);
		this.salary = salary;
	}
	void display() {
		System.out.println("Name:"+name+"\n"+"id:"+id+"\n"+"salary:"+salary);
	}

	
	
}
