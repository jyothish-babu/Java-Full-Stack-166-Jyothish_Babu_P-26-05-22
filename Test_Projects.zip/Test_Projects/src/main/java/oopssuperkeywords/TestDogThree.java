package oopssuperkeywords;

public class TestDogThree {

	public static void main(String[] args) {
		DogThree d=new DogThree();

	}

}
