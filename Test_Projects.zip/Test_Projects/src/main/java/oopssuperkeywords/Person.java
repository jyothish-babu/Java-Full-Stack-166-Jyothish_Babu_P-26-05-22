package oopssuperkeywords;

public class Person {
	String name;
	int id;
	
	public Person(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	
	
	

}
