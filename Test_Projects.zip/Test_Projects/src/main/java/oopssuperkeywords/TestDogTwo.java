package oopssuperkeywords;

public class TestDogTwo {

	public static void main(String[] args) {
		DogTwo d=new DogTwo();
		

	}

}
