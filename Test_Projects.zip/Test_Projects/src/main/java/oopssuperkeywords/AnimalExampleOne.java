package oopssuperkeywords;

public class AnimalExampleOne {
	String name="catt";
//	AnimalExampleOne(String name){
//		this.name=name;
//	}

}
