package oopssuperkeywords;

public class TestAnimalExample {

	public static void main(String[] args) {
		//AnimalExampleOne an= new AnimalExampleOne("cat");
		AnimalExampleTwo an2= new AnimalExampleTwo(3);
		
		//an.display();
		an2.display();

	}

}
