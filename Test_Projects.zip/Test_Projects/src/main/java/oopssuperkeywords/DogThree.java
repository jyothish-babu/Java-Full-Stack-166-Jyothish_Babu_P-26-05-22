package oopssuperkeywords;

public class DogThree extends AnimalThree{
	DogThree() {
		System.out.println("Dog is printed");
	}

}
