package oopssuperkeywords;

public class AnimalDog extends Animal {
	void eating() {
		super.eat();
		System.out.println("eating meet");
	}
	

}
