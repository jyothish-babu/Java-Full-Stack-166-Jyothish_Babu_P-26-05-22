package oopssuperkeywords;

public class AnimalThree {
	AnimalThree() {
		System.out.println("animal is printed");
	}

}
