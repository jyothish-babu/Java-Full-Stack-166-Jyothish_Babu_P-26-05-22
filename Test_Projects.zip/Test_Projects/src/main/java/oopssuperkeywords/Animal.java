package oopssuperkeywords;

public class Animal {
	void eat() {
		System.out.println("food");
	}

}
