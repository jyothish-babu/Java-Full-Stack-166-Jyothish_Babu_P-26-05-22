package packages.mypack;

//import packages.pack.A;
//import packages.pack.*;

public class B {

	public static void main(String[] args) {
		packages.pack.A obj=new packages.pack.A();
		obj.msg();
		

	}

}
