package multithreading;

public class StartThreadOne extends Thread {
	public void run() {
		System.out.println("thread is runing");
	}
	public static void main(String[] args) {
		StartThreadOne t1=new StartThreadOne();
		StartThreadOne t2=new StartThreadOne();
		
		t1.start();
		t2.start();
	}

}
