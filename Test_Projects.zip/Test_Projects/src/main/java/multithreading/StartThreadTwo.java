package multithreading;

public class StartThreadTwo implements Runnable {

	@Override
	public void run() {
		System.out.println("thread is running...");

	}

	public static void main(String[] args) {
		StartThreadTwo t1 = new StartThreadTwo();
		Thread t2 = new Thread(t1);
		t2.start();
		
		t2.setName("threadone");
		System.out.println(t2.getName());

	}
}
