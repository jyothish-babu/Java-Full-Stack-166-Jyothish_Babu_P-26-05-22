package multithreading;

public class StartThreadFour implements Runnable {
	@Override
	public void run() {
		System.out.println("thread is runing");
		
	}

	public static void main(String[] args) {
		Runnable t1=new StartThreadFour();
		Thread t2=new Thread(t1,"threads");
		
		System.out.println(t2.getName());
		t2.start();
		
		t2.setName("thread2");
		System.out.println(t2.getName());
		

	}

	

}
