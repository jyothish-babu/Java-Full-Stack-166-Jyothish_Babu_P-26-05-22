package multithreading;

public class StartThreadThree {

	public static void main(String[] args) {
		Thread t1=new Thread("thread is running");
		t1.getName();
		System.out.println(t1.getName());
		
		t1.setName("name changed");
		System.out.println(t1);
		

	}

}
