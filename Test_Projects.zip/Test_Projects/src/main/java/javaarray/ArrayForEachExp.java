package javaarray;

public class ArrayForEachExp {

	public static void main(String[] args) {
		int arr[]= {22,35,56};
		for(int i:arr) {
			System.out.println(i);
		}

	}

}
