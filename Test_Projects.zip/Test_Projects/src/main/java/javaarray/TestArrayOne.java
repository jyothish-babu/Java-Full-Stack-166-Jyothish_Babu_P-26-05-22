package javaarray;

public class TestArrayOne {

	public static void main(String[] args) {
		int a[]={33,22,55};
		ArrayOne.min(a);
	}

}
