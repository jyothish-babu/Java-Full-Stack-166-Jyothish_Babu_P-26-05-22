package javaarray;

public class ArrayMethod {
	static int[] get() {
		return new int[] {20,30,40};
	}

}
