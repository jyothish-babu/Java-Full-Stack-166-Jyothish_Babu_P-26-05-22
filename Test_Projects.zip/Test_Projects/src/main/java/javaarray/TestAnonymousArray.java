package javaarray;

public class TestAnonymousArray {

	public static void main(String[] args) {
		AnonymousArray.printArray(new int[] {22,33,45});
	}

}
