package javaarray;

public class TestArray {

	public static void main(String[] args) {
		int a[]=new int[5];
		a[0]=20;
		a[1]=25;
		a[2]=30;
		a[3]=45;
		a[4]=50;
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}

	}

}
