package stringclass;

public class StringExample {

	public static void main(String[] args) {
		char ch[]={'s','t','r','i','n','g'};
		String s1="java";
		String s2=new String(ch);
		String s3=new String("Example");
		
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);

	}

}
