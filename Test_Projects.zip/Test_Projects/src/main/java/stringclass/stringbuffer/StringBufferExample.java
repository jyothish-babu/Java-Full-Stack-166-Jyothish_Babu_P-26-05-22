package stringclass.stringbuffer;

public class StringBufferExample {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("java");
		System.out.println(sb);
		sb.append(" string");
		System.out.println(sb);
		
		
		sb.insert(1,"aa");
		System.out.println(sb);
		
		sb.replace(1, 3,"java");
		System.out.println(sb);
		
		sb.delete(1, 3);
		System.out.println(sb);
		
		sb.reverse();
		System.out.println(sb);
		
		StringBuffer sb1=new StringBuffer();
		
		sb1.append("HELLO");
		System.out.println(sb1.capacity());
		sb1.append("java");
		System.out.println(sb1.capacity());
		sb1.append(" java is my favorate language");
		System.out.println(sb1.capacity()); //now (16*2)+2=34 i.e (oldcapacity*2)+2 

	}

}
