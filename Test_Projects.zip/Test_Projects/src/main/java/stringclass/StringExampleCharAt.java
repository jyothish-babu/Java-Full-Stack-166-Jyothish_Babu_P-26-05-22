package stringclass;

public class StringExampleCharAt {

	public static void main(String[] args) {
		String s1 = "welcome to india";
		String s2 = "hello";
		String s3 = "hello";
		String s4 = "walk";
		String s5 = "";
		char ch = s1.charAt(11);
		System.out.println(ch);
		System.out.println();

//		char ch1=s1.charAt(18);
//		System.out.println(ch1);  //String Index Out Of Bounds Exception with charAt()

		int length = s1.length();
		System.out.println("First char of string s1:" + s1.charAt(0)); // print char @ first and last index
		System.out.println("Final char of string s1:" + s1.charAt(length - 1));
		System.out.println();

		for (int i = 0; i < s1.length(); i++) { // Accessing all the elements present at odd index
			if (i % 2 != 0) {
				System.out.println("chae at index" + i + " " + s1.charAt(i));
			}
		}
		System.out.println();

		int count = 0; // Counting frequency of a character in the string
		for (int i = 0; i < s1.length(); i++) {
			if (s1.charAt(i) == 'e') {
				count++;
			}
		}
		System.out.println("frequency of e:" + " " + count);
		System.out.println();

		System.out.println(s1.compareTo(s2)); // String compare to another String
		System.out.println(s2.compareTo(s3));
		System.out.println(s3.compareTo(s4));
		System.out.println(s3.compareTo(s5)); // String compare to an empty String
		System.out.println(s5.compareTo(s3)); // s1 == s2 :0
												// s1 > s2 :positive value
		System.out.println(); // s1 < s2 :negative value

		String ss = s1.concat(" " + s2); // string concat()
		System.out.println(ss);
		ss = s1.concat(" " + "hello all"); // string concat() combined a string at the end of the string
		System.out.println(ss);
		System.out.println(s1.concat(s2).concat(s4)); // multiple string concat
		System.out.println(s1.concat(s2).concat(" ").concat(s4)); // Concatenating spaces and special chars
		System.out.println(s1.concat("@").concat(s2));
		System.out.println(50 + 50 + "sachin" + 40 + 40); // 100sachin4040
		System.out.println();

		// -------------------------------------------------------------------------------

		String str = "Hello Steps Kochi readers";
		String str1 = " Sachin ";
		String str2 = "Sachin";
		String str3 = "SACHIN";
		String str4 = "Saurav";
		String str5 = new String("Sachin"); // (1)

		boolean st = str.contains("Steps"); // if contains a string
		System.out.println(st);
		System.out.println(str.contains("steps"));
		System.out.println();

		System.out.println(str1.equals(str2)); // equals check with 2 string
		System.out.println(str2.equals(str4));
		System.out.println(str2.equals(str3));
		System.out.println();

		System.out.println(str2.equals(str3));
		System.out.println(str2.equalsIgnoreCase(str3)); // equals check equalIngnoreCase(ingnore upper case and lower
															// case
		System.out.println();

		System.out.println(str1 == str2);
		System.out.println(str1 == str5); // (1) string store in different m/y space
		System.out.println();

		System.out.println(str1.toUpperCase()); // upper case & lower case
		System.out.println(str3.toLowerCase());
		System.out.println();

		System.out.println(str1); // trim both side spaces of the given string
		System.out.println(str1.trim());
		System.out.println();

		System.out.println(str2.startsWith("Sa")); // return true if it satisfay
		System.out.println(str2.endsWith("n"));
		System.out.println();

		System.out.println(str2.length()); // length of the string
		System.out.println();

		String s = str5.intern();
		System.out.println(s);
		System.out.println();

		int b = 20;
		String b1 = String.valueOf(b);
		System.out.println(10 + b1); // int to string
		System.out.println();
		
		String sr="Java is a programming language"; //replace 
		String sr1=sr.replace("Java", "kava");
		System.out.println(sr1);
		
	    System.out.println(sr.codePointAt(2)); //Unicode code point
		

	}

}
