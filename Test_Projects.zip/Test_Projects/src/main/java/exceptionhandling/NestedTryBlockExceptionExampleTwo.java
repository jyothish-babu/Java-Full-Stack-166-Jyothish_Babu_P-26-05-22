package exceptionhandling;

public class NestedTryBlockExceptionExampleTwo {

	public static void main(String[] args) {
		try {
			try {
				try {
					int data=50/0;
				}
				catch(ArithmeticException e) {
					System.out.println(e);
				}
				int a[]=new int[5];
				a[5]=5;
				
			}
			catch(ArrayIndexOutOfBoundsException e) {
				System.out.println(e);
			}
			
		}
		catch(Exception e) {       //handle the exception outter catch
			System.out.println("handle the exception outter catch");
		}

	}

}
