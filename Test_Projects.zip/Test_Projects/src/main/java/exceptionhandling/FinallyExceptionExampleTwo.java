package exceptionhandling;

public class FinallyExceptionExampleTwo {

	public static void main(String[] args) {
		try {
			int data=50/0;
		}
		catch(NullPointerException e) {   //cannot handle Arithmetic type exception  can only accept Null Pointer type exception
			System.out.println(e);
		}
		finally {
			System.out.println("finally block is alwase exicute");  //finally block is alwase exicute
		}
		System.out.println("rest of the code");

	}

}
