package exceptionhandling;

public class ExampleOne {

	public static void main(String[] args) {
		int a=5;
		int b=9;
		
		try {
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a/0);
		System.out.println(a*b);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
	}

}
