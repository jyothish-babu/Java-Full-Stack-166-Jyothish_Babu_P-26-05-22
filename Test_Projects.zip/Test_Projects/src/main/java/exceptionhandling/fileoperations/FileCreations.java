package exceptionhandling.fileoperations;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileCreations {

	public static void main(String[] args) {
		try {
			File f0=new File("FileExample.txt");
			FileWriter fw=new FileWriter("FileExample.txt");
			Scanner dr=new Scanner(f0);
			
			if(f0.createNewFile()) {
				System.out.println("file "+f0.getName()+"is created");
			}else {
				//System.out.println("file is already exist");
				System.out.println(f0.getName());
				System.out.println(f0.getAbsolutePath());
				System.out.println(f0.canWrite());
				System.out.println(f0.canRead());
				System.out.println(f0.length());
				
				fw.write("Hello");
				fw.close();
				System.out.println(f0.length());
				
				System.out.println("reading from file");
				while(dr.hasNextLine()) {
					String fileData=dr.nextLine();
					System.out.println(fileData);
				}
				dr.close();
				
				
				
			}
			//f0.delete();
			
		}
		catch(IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}

	}

}
