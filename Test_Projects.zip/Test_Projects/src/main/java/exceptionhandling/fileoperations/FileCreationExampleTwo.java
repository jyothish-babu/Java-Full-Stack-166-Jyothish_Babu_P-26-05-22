package exceptionhandling.fileoperations;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class FileCreationExampleTwo {

	public static void main(String[] args) {
		try {
			File file=new File("Data File.txt");
			FileWriter fw=new FileWriter(file);
			Scanner sc=new Scanner(file);
			if(file.createNewFile()) {
				System.out.println("file is created");
			}
			else {
				System.out.println(file.getName());
				System.out.println(file.getAbsolutePath());
				
				fw.write("JAVA");
				fw.close();
				
				while(sc.hasNextLine()) {
					String str=sc.nextLine();
							System.out.println(str);
				}
				sc.close();
				
				
				
				
			}
			//file.delete();
		}
		catch(Exception e) {
			System.out.println(e);
		}

	}

}
