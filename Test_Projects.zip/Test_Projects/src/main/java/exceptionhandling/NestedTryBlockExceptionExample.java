package exceptionhandling;

public class NestedTryBlockExceptionExample {

	public static void main(String[] args) {
		
		try {                      //outer try block
			try {                  //inner try block1
				int data=50/0;
			}
			catch(ArithmeticException e) {
				System.out.println(e);
			}
			try {                  //inner try block2
				int a[]=new int[5];
				a[5]=5;
			}
			catch(ArrayIndexOutOfBoundsException e) {
				System.out.println(e);
			}
			
		}
		catch(Exception e) {       //handle the exception outter catch
			System.out.println("handle the exception outter catch");
		}
		finally {
			System.out.println("finally block is alwase exicuted");
		}

	}

}
