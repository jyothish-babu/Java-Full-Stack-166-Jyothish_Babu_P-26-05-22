package exceptionhandling;

public class ExceptionExampleFive {

	public static void main(String[] args) {
		try {
			int a[]= {2,5,6};
			System.out.println(a[10]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		System.out.println("rest of the code");

	}

}
