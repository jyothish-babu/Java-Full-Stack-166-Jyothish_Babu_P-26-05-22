package exceptionhandling;

public class FinallyExceptionExample {

	public static void main(String[] args) {
		try {
			int data=50/0;
		}
		catch(ArithmeticException e) {
			System.out.println(e);
		}
		finally {     //finally block is always executed
			System.out.println("Finally block is allwase exicuted");
		}
		System.out.println("rest of the code");

	}

}
