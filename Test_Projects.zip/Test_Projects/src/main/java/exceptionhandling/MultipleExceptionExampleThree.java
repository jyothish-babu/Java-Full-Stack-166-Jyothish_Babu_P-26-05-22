package exceptionhandling;

public class MultipleExceptionExampleThree {  //Compile-time error

	public static void main(String[] args) {
		try {
			String str=null;
			System.out.println(str.length());
		}
		catch(Exception e) {
			System.out.println("parent exception occured");
		}
//		catch(ArithmeticException e) {
//			System.out.println("ArithmeticException occured");
//		}
//		catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println("ArrayIndexOutOfBoundsException occured");
//		}

	}

}
