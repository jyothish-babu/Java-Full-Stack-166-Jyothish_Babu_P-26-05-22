package exceptionhandling;

public class ExceptionExampleFour {

	public static void main(String[] args) {
		int data;
		int i=5;
		int j=0;
		
		try {
			data=i/j;
		}
		catch(ArithmeticException e) {
			System.out.println(i/j);
		}
		System.out.println("rest of the code");


	}

}
