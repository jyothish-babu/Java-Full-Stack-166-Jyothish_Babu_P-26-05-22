package exceptionhandling;

public class ThrowExceptionExample {
	
	public static void vote(int age) {
		if(age<18) {
			throw new ArithmeticException("not eligible for voting");
		}
		else {
			System.out.println("eligible for voting");
		}
		
	}

	public static void main(String[] args) {
		
		ThrowExceptionExample.vote(16);

	}

}
