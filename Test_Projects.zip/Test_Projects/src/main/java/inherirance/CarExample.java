package inherirance;

public class CarExample {
	String model;
	int price;
	
	void setModel(String model) {
		this.model=model;
	}
	String getModel() {
		return model;
	}
	
	
	void setPrice(int price) {
		this.price=price;
	}
	int getPrice() {
		return price;
	}
	
	void start() {
		System.out.println("car is started");
	}
	void move() {
		System.out.println("car is moving");
	}
	void stop() {
		System.out.println("stoped");
	}

}
