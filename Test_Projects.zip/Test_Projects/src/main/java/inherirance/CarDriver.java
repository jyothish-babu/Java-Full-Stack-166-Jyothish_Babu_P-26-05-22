package inherirance;

public class CarDriver {
	String name;
	int age;
	
	void setNmae(String name) {
		this.name=name;
	}
	
	String getName() {
		return name;
	}
	
	
	void setAge(int age) {
		this.age=age;
	}
	int getAge() {
		return age;
	}

}
