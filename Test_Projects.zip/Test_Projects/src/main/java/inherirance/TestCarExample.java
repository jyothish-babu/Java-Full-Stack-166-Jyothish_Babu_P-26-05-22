package inherirance;

public class TestCarExample {

	public static void main(String[] args) {
		CarExample car=new CarExample();
		CarDriver dr=new CarDriver();
		
		dr.setNmae("Arun");
		System.out.println(dr.getName());
		dr.setAge(25);
		System.out.println(dr.getAge());
		
		car.setModel("honda");
		System.out.println(car.getModel());
		
		car.setPrice(500000);
		System.out.println(car.getPrice());
		
		
		car.start();
		car.move();
		car.stop();
		
		

	}

}
