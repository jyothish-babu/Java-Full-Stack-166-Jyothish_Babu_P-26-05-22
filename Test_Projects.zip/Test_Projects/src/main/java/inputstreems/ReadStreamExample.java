package inputstreems;

import java.io.FileInputStream;
import java.io.InputStream;

public class ReadStreamExample {

	public static void main(String[] args) {
		try {
			InputStream  is=new FileInputStream("Data File.txt");
			System.out.println("Data in the file:");
			int i=is.read();
			while(i!=-1) {
				System.out.print((char)i);
				i=is.read();
			}
			is.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
