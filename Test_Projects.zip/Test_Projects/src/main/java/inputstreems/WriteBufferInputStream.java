package inputstreems;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class WriteBufferInputStream {

	public static void main(String[] args) {
		String data = "good morning all";
		try {
			FileOutputStream file = new FileOutputStream("JavaExmp.txt");
			BufferedOutputStream buffer = new BufferedOutputStream(file);

			byte[] array = data.getBytes();
			buffer.write(array);
			buffer.close();
			
		} catch (Exception e) {
			e.getStackTrace();
		}

	}

}
