package inputstreems;

import java.io.ByteArrayOutputStream;

public class ExampleToByteArray {

	public static void main(String[] args) {
		String data="java code";
		try {
			ByteArrayOutputStream data1=new ByteArrayOutputStream();
			data1.write(data.getBytes());
			
			byte[] array=data1.toByteArray();
			for(int i=0;i<data.length();i++) {
				System.out.print((char)array[i]);
			}
			
			String str=data1.toString();
			System.out.print("\n"+"Data string:"+str);
			data1.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}
		

	}

}
