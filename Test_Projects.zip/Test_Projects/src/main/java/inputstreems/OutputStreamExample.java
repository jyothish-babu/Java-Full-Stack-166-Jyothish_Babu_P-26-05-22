package inputstreems;

import java.io.FileOutputStream;
import java.io.OutputStream;

public class OutputStreamExample {

	public static void main(String[] args) {
		String data="java is a powerfull language";
		try {
			OutputStream out=new FileOutputStream("Data File.txt");
			byte arrayData[]=data.getBytes();
			out.write(arrayData);
			System.out.println("data write to file successfully");
			out.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}
		

	}

}
