package inputstreems;

import java.io.ByteArrayOutputStream;

public class WriteByteArrayInputStreamExp {

	public static void main(String[] args) {
		String data="code to perform java stream";
		try {
			ByteArrayOutputStream data1=new ByteArrayOutputStream();
			byte[] array=data.getBytes();
			data1.write(array);
			
			String str=data1.toString();
			System.out.println("out data:"+str);
			data1.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
