package inputstreems;

import java.io.ByteArrayInputStream;

public class AvailableByteArrayInputStream {

	public static void main(String[] args) {
		byte[] array= {8,6,5,9};
		try {
			ByteArrayInputStream data=new ByteArrayInputStream(array);
			System.out.print("available bytes at the begining:"+data.available()+"\n");
			data.read();
			data.read();
			System.out.print("available bytes at the end:"+data.available());
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
