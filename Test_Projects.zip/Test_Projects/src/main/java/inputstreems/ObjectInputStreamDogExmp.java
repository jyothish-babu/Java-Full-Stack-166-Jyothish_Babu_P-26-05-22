package inputstreems;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ObjectInputStreamDogExmp implements Serializable {
	String name;
	String breed;

	public ObjectInputStreamDogExmp(String name, String breed) {
		super();
		this.name = name;
		this.breed = breed;
	}

	public static void main(String[] args) {
		ObjectInputStreamDogExmp dog=new ObjectInputStreamDogExmp("achu","lab");
		try {
		FileOutputStream file=new FileOutputStream("Data File.txt");
		ObjectOutputStream objFile=new ObjectOutputStream(file);
		
		objFile.writeObject(dog);
		
		FileInputStream file2=new FileInputStream("Data File.txt");
		ObjectInputStream objFile2=new ObjectInputStream(file2);
		
		ObjectInputStreamDogExmp newDog=(ObjectInputStreamDogExmp) objFile2.readObject();
		System.out.println("Dog name: "+newDog.name);
		System.out.println("Dog breed: "+newDog.breed);
		
		objFile.close();
		objFile2.close();
		
		
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
