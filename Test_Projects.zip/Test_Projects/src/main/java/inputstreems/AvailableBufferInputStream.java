package inputstreems;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class AvailableBufferInputStream {

	public static void main(String[] args) {
		try {
			FileInputStream file=new FileInputStream("Data File.txt");
			BufferedInputStream b1=new BufferedInputStream(file);
			System.out.println("print begining read: "+b1.available());
			b1.read();
			b1.read();
			b1.read();
			System.out.println("after read: "+b1.available());
			b1.close();
			
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
