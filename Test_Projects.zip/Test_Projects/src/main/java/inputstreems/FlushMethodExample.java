package inputstreems;

import java.io.FileOutputStream;

public class FlushMethodExample {

	public static void main(String[] args) {
		String str="Have a nice day";
		try {
			FileOutputStream file=new FileOutputStream("Data File.txt");
			file.write(str.getBytes());
			file.flush();
			System.out.println("file is successfully writed");
			file.close();
			
		}
		catch(Exception e) {
			e.getStackTrace();		}

	}

}
