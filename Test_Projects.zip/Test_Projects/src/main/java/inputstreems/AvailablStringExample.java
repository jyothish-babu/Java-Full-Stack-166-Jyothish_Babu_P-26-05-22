package inputstreems;

import java.io.FileInputStream;
import java.io.InputStream;

public class AvailablStringExample {

	public static void main(String[] args) {
		try {
			InputStream st=new FileInputStream("Data File.txt");
			System.out.println("String at the begining"+st.available());
			st.read();
			st.read();
			st.read();
			System.out.println("String at the end"+st.available());
			st.close();
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
