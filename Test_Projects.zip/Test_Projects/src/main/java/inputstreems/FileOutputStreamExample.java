package inputstreems;

import java.io.FileOutputStream;

public abstract class FileOutputStreamExample {
	public static void main(String[] args) {
		String data = "this is ajava program";
		try {
			FileOutputStream file = new FileOutputStream("Data File.txt");
			byte[] array = data.getBytes();
			file.write(array);
			System.out.println("write successfully");
			file.close();
		} catch (Exception e) {
			e.getStackTrace();
		}
	}

}
