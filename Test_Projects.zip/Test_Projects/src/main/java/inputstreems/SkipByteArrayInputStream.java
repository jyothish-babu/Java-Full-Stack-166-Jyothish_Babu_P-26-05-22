package inputstreems;

import java.io.ByteArrayInputStream;

public class SkipByteArrayInputStream {

	public static void main(String[] args) {
		byte[] array= {5,5,9,3};
		try {
			ByteArrayInputStream data=new ByteArrayInputStream(array);
			data.skip(2);
		    int data1=data.read();
		    while(data1!=-1)
		    {
		    	System.out.print(data1+",");
		    	data1=data.read();
			}
			data.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
