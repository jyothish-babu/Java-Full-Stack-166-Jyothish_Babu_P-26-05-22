package inputstreems;

import java.io.BufferedInputStream;

import java.io.FileInputStream;

public class SkipBufferInputStreamExp {

	public static void main(String[] args) {
		try {
			FileInputStream file=new FileInputStream("JavaExmp.txt");
			BufferedInputStream buf=new BufferedInputStream(file);
			
			buf.skip(4);
			
			int i=buf.read();
			while(i!=-1) {
				System.out.print((char)i);
				i=buf.read();
			}
			buf.close();
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}
	}

}
