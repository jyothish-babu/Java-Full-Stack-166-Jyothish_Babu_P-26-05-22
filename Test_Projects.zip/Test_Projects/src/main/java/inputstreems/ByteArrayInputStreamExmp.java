package inputstreems;

import java.io.ByteArrayInputStream;

public class ByteArrayInputStreamExmp {

	public static void main(String[] args) {
		byte[] array= {1,2,3,6};
		try {
			ByteArrayInputStream data=new ByteArrayInputStream(array);
			System.out.print("The bytes read from the input stream: ");
			for(int i=0;i<array.length;i++) {
				int read=data.read();
				System.out.print(read+",");
			}
			data.close();
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
