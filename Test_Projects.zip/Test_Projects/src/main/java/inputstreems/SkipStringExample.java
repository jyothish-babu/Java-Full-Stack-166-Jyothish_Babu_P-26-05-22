package inputstreems;

import java.io.FileInputStream;
import java.io.InputStream;

public class SkipStringExample {

	public static void main(String[] args) {
		try {
			InputStream st=new FileInputStream("Data File.txt");
			st.skip(5);
			int i=st.read();
			while(i!=-1) {
				System.out.print((char)i);
				i=st.read();
				
			}
			st.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
