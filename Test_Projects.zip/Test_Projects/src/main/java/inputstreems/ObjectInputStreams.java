package inputstreems;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
public class ObjectInputStreams {


	public static void main(String[] args) {
		int data1=555;
		String data2="apple";
		try {
			FileOutputStream file=new FileOutputStream("Data File.txt");
			ObjectOutputStream objFile=new ObjectOutputStream(file);
			objFile.writeInt(data1);
			objFile.writeObject(data2);
			
			
			FileInputStream fileOne=new FileInputStream("Data File.txt");
			ObjectInputStream objStream=new ObjectInputStream(fileOne);
			
			System.out.println("Integer value: "+objStream.readInt());
			System.out.println("String value: "+objStream.readObject());
			
			objFile.close();
			objStream.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
