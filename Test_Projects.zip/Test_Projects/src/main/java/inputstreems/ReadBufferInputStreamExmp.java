package inputstreems;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class ReadBufferInputStreamExmp {

	public static void main(String[] args) {
		
		
		try {
		FileInputStream file=new FileInputStream("Data File.txt");
		BufferedInputStream b1=new BufferedInputStream(file);
		int i=b1.read();
		while(i!=-1) {
			System.out.print((char)i);
			i=b1.read();
		}
		b1.close();
		}
		catch(Exception e) {
			e.getStackTrace();
		}
		

	}

}
