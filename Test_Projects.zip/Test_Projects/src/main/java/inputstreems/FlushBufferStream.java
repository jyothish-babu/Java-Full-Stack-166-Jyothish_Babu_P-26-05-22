package inputstreems;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class FlushBufferStream {

	public static void main(String[] args) {
		String str="good";
		try {
			FileOutputStream file=new FileOutputStream("JavaExmp.txt");
			BufferedOutputStream buffer=new BufferedOutputStream(file);
			buffer.write(str.getBytes());
			buffer.flush();
			System.out.println("flushed");
			buffer.close();
			
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}

	}

}
