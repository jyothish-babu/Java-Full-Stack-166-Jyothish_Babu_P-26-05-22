package inputstreems;

import java.io.FileInputStream;
import java.io.InputStream;

public class InputStreamExample {

	public static void main(String[] args) {
		byte array[] = new byte[100];

		try {
			InputStream data = new FileInputStream("Data File.txt");
			System.out.println("Available bytes in file:" + data.available());
			data.read(array); // read input from the input stream
			String strData = new String(array); // convert byte array into string
			System.out.println("Data in the file is:" + strData);
			data.close();
		} catch (Exception e) {
			e.getStackTrace();
		}

	}

}
