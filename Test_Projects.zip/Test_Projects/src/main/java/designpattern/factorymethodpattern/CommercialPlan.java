package designpattern.factorymethodpattern;

public class CommercialPlan extends Plan {
	public void getRate() {
		rate=3.55;
	}
}
