package designpattern.factorymethodpattern;

public class InstitutionalPlan extends Plan {
	@Override
	void getRate() {
		rate=4.35;
	}

}
