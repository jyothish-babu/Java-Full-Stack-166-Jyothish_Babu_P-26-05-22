package designpattern.factorymethodpattern;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GenerateBill {

	public static void main(String[] args) throws IOException {
		GetPlanFactory planFactory=new GetPlanFactory();
		
		System.out.println("Enter the name of paln for which the bill will be generated");
		BufferedReader planName=new BufferedReader(new InputStreamReader(System.in));
		
		String strPlanName=planName.readLine();
		
		System.out.println("Enter the number of unit for bill will be calculate");
		int unit=Integer.parseInt(planName.readLine());
		
	    Plan p=planFactory.getPlan(strPlanName);
	    
	    
	    System.out.println("bill amount for"+strPlanName+" of "+unit+" unit is ");
	    p.getRate();
	    p.calculateBill(unit);
	}

}
