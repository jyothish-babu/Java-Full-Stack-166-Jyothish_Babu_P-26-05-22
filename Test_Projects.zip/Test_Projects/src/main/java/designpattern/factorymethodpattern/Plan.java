package designpattern.factorymethodpattern;

abstract class Plan {

	protected double rate;

	void getRate() {

	}

	void calculateBill(int unit) {
		System.out.println(unit * rate);

	}

}
