package inheriranceoverriding;

public class TestBank2 {

	public static void main(String[] args) {
		Bank2 b;
		
		b=new SBI2();
		System.out.println("SBI rate of Interest:"+b.getRateOfInterest());
		
		b=new AXIS2();
		System.out.println("AXIS rate of Interest:"+b.getRateOfInterest());
		
		System.out.println("SBI rate of Interest:"+b.getRateOfInterest()); // in this case obj variable use same m/y loc and each time they creat a copy of m/y loc 'b' 

	}

}
