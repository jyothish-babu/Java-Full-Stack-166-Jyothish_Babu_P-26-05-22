package inheriranceoverriding;

public class AXIS extends Bank {
	int getRateOfInterest() {
		return 6;
	}

}
