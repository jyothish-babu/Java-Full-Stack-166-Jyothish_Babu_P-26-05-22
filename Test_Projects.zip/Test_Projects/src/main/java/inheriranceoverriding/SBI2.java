package inheriranceoverriding;

public class SBI2 extends Bank2{
	int getRateOfInterest() {
		return 9;
	}

}
