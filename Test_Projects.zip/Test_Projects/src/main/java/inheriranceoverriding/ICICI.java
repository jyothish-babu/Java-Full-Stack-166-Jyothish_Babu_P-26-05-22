package inheriranceoverriding;

public class ICICI extends Bank {
	int getRateOfInterest() {
		return 5;
	}

}
