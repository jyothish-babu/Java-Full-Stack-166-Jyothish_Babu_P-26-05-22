package inheriranceoverriding;

public class SBI extends Bank {
	int getRateOfInterest() {
		return 8;
	}

}
