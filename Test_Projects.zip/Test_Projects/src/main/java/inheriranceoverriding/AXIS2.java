package inheriranceoverriding;

public class AXIS2 extends Bank2{
	int getRateOfInterest() {
		return 6;
	}

}
