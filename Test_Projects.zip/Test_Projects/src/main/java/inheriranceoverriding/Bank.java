package inheriranceoverriding;

public class Bank {
	int getRateOfInterest() {
		return 0;
	}

}
