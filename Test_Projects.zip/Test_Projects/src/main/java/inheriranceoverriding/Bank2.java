package inheriranceoverriding;

public class Bank2 {
	int getRateOfInterest() {
		return 0;
	}

}
