package collectionsExample.linkedhashset;

import java.util.LinkedHashSet;

import collectionsExample.hashset.BookHashSet;

public class TestBookLinkedHashSet {

	public static void main(String[] args) {
		LinkedHashSet<BookLinkedHashSet> lset=new LinkedHashSet<BookLinkedHashSet>();
		
		BookLinkedHashSet b=new BookLinkedHashSet(101, "arun", "vimal", "soman", 5);
		BookLinkedHashSet b1=new BookLinkedHashSet(101, "ammu", "felix", "soman", 10);
		BookLinkedHashSet b2=new BookLinkedHashSet(101, "keshavan", "kannan", "vimal", 8);
		
		lset.add(b);
		lset.add(b1);
		lset.add(b2);
		
		for(BookLinkedHashSet bl:lset) {
			System.out.println("id:"+bl.id+" name:"+bl.name+" author:"+bl.author+" pubisher"+bl.publisher+" quantity:"+bl.quantity);
		}

	}

}
