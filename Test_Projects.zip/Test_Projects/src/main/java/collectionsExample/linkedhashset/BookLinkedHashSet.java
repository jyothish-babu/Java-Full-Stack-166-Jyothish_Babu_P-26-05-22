package collectionsExample.linkedhashset;

public class BookLinkedHashSet {

		int id;
		String name,author,publisher;
		int quantity;
		public BookLinkedHashSet(int id, String name, String author, String publisher, int quantity) {
			super();
			this.id = id;
			this.name = name;
			this.author = author;
			this.publisher = publisher;
			this.quantity = quantity;
		}
		

}
