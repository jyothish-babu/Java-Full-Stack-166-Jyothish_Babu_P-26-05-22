package collectionsExample.linkedhashset;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetOne {  //duplicate element terminated

	public static void main(String[] args) {
		LinkedHashSet<String> lset=new LinkedHashSet<String>();
		lset.add("soman");
		lset.add("felix");
		lset.add("subin");
		lset.add("adhwide");
		lset.add("subin");
		
		Iterator<String> itr=lset.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		lset.remove("felix");
		System.out.println(lset);
		
		System.out.println(lset.remove("xyz"));
		
		

	}

}
