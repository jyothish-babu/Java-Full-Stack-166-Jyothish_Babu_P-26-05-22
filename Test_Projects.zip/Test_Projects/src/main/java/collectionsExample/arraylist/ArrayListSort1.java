package collectionsExample.arraylist;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListSort1 {

	public static void main(String[] args) {
		ArrayList<Integer> list1=new ArrayList<Integer>();
		list1.add(101);
		list1.add(201);
		list1.add(99);
		list1.add(59);
		
		Collections.sort(list1);
		
		for(Integer intg:list1) {
			System.out.println(intg);
		}
		
		

	}

}
