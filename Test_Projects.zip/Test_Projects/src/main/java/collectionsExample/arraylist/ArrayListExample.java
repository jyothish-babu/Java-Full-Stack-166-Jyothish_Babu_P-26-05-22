package collectionsExample.arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		
		list.add("anu");
		list.add("athira");
		list.add("ammu");
		list.add("anu");
		
		//System.out.println(list);  //sysout method
		
		Iterator itr=list.iterator(); //iterator method
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
