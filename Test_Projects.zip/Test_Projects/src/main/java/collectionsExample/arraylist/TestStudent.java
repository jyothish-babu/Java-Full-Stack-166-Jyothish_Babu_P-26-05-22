package collectionsExample.arraylist;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestStudent {

	public static void main(String[] args) {
		Student s1=new Student(10,"anu",25);
		Student s2=new Student(11,"ammu",26);
		Student s3=new Student(12,"kavya",27);
		
		List<Student> list1=new ArrayList<Student>();
		list1.add(s1);
		list1.add(s2);
		list1.add(s3);
		
		
		Iterator itr=list1.iterator();
		
		while(itr.hasNext()) {
			Student stu=(Student)itr.next();
			System.out.println(stu.rollNo+" "+stu.name+" "+stu.age);
		}
	}

}
