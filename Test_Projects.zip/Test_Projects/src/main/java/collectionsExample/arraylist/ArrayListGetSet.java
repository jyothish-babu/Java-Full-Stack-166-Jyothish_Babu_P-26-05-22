package collectionsExample.arraylist;

import java.util.ArrayList;

public class ArrayListGetSet {

	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		list.add("adhwid");
		list.add("felix");
		list.add("soman");
		list.add("subin");
		
		System.out.println("getting values: "+list.get(1));
		
		list.set(1, "vinu");
		
		for(String str:list) {
			System.out.println();
		}

	}

}
