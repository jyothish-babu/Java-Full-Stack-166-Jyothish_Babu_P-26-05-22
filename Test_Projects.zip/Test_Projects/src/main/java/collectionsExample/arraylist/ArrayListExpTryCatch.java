package collectionsExample.arraylist;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ArrayListExpTryCatch {

	public static void main(String[] args) {
		ArrayList<String> list5=new ArrayList<String>();
		list5.add("felix");
		list5.add("subin");
		list5.add("adhwid");
		list5.add("soman");
		
		try {
			FileOutputStream fileOut=new FileOutputStream("file");
			ObjectOutputStream objOut=new ObjectOutputStream(fileOut);
			objOut.writeObject(list5);
			objOut.close();
			fileOut.close();
			
			FileInputStream fileIn=new FileInputStream("file");
			ObjectInputStream objIn=new ObjectInputStream(fileIn);
			ArrayList<String> readList5=(ArrayList)objIn.readObject();
			System.out.println(readList5);
			
		}
		catch(Exception e) {
			System.out.println(e);
		}

	}

}
