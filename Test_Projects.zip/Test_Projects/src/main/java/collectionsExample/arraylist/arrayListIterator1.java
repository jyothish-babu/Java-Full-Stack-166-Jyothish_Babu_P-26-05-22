package collectionsExample.arraylist;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class arrayListIterator1 {

	public static void main(String[] args) {
		ArrayList<String> list4=new ArrayList<String>();
		list4.add("adhwid");
		list4.add("felix");
		list4.add("soman");
		list4.add("subin");
		
		System.out.println("traversing list throuth list iterator");
		ListIterator<String> llist=list4.listIterator(list4.size()); 
		while(llist.hasPrevious()) {
			String str=llist.previous();
			System.out.println(str);
		}
		
		System.out.println("travresing list through for loo");
		for(int i=0;i<list4.size();i++) {
			System.out.println(list4.get(i));
		}
		
		System.out.println("traversing list through forEach() method");
//		for(String str2:list4) {
//			System.out.println(str2);
//		}
		list4.forEach(a->{System.out.println(a);});
		
		System.out.println("traversing lidt through forEachRemaining() method");
		Iterator<String> str6=list4.iterator();
		str6.forEachRemaining(b->{System.out.println(b);});
		
		
	}

}
