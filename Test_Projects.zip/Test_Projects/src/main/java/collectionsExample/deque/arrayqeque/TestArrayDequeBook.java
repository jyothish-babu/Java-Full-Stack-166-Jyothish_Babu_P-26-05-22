package collectionsExample.deque.arrayqeque;

import java.util.ArrayDeque;
import java.util.Queue;

public class TestArrayDequeBook {

	public static void main(String[] args) {
		Queue<ArrayDequeBook> queue=new ArrayDeque<ArrayDequeBook>();
		
		ArrayDequeBook book=new ArrayDequeBook(101, "ab", "bc", "cd", 5);
		ArrayDequeBook book1=new ArrayDequeBook(101, "abc", "bce", "cdg", 6);
		ArrayDequeBook book2=new ArrayDequeBook(101, "abcd", "befc", "cdhj", 8);
		
		queue.add(book2);
		queue.add(book);
		queue.add(book1);
		
		for(ArrayDequeBook b:queue) {
			System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);
		}
		

	}

}
