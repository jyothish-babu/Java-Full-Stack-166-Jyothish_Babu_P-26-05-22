package collectionsExample.deque.arrayqeque;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeTwo {
	public static void main(String[] args) {
		Deque<String> deque=new ArrayDeque<String>();
		deque.offer("apple");
		deque.offer("mango");
		deque.offer("banana");
		deque.add("cat");
		deque.offerFirst("grapes");
		
		for(String s:deque) {
			System.out.println(s);
		}
		System.out.println();
		
		deque.pollLast();
		for(String s:deque) {
			System.out.println(s);
		}
		
	}
	
	
	

}
