package collectionsExample.deque.arrayqeque;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

public class ArrayDequeOne {

	public static void main(String[] args) {
		Deque<String> deque=new ArrayDeque<String>();
		deque.add("apple");
		deque.add("orange");
		deque.add("grapes");
		deque.add("mango");
		
		Iterator<String> str=deque.iterator();
		while(str.hasNext()) {
			System.out.println(str.next());
		}
	}

}
