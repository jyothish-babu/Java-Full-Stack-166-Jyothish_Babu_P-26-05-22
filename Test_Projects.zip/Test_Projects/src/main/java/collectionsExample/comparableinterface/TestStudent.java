package collectionsExample.comparableinterface;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class TestStudent{

	public static void main(String[] args) {
		ArrayList<Student> list=new ArrayList<Student>();
		
		list.add(new Student(101, 19, "vinu"));
		list.add(new Student(102, 18, "vimal"));
		list.add(new Student(102, 20, "rahul"));
		
		Collections.sort(list);
		for(Student ss:list) {
			System.out.println("rollNo:"+ss.rollno+" age:"+ss.age+" name:"+ss.name);
		}
		

	}

}
