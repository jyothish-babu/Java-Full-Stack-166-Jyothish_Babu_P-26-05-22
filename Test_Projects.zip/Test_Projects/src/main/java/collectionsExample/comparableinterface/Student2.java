package collectionsExample.comparableinterface;

public class Student2 implements Comparable<Student2>{
	int rollno,age;
	String name;
	

	public Student2(int rollno, int age, String name) {
		super();
		this.rollno = rollno;
		this.age = age;
		this.name = name;
	}


	@Override
	public int compareTo(Student2 o) {
		if(age==o.age) 
			return 0;
		else if(age>o.age) 
			return 1;
		else 
			return -1;
	}
	

}
