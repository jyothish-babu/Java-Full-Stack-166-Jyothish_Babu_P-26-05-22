package collectionsExample.comparableinterface;

import java.util.ArrayList;
import java.util.Collections;

public class TestStudent2 {

	public static void main(String[] args) {
ArrayList<Student2> list=new ArrayList<Student2>();
		
		list.add(new Student2(101, 19, "vinu"));
		list.add(new Student2(102, 18, "vimal"));
		list.add(new Student2(102, 20, "rahul"));
		
		Collections.sort(list);
		for(Student2 ss:list) {
			System.out.println("rollNo:"+ss.rollno+" age:"+ss.age+" name:"+ss.name);
		}

	}

}
