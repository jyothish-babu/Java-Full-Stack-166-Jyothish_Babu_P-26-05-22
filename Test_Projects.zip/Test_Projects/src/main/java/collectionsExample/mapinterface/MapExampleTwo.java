package collectionsExample.mapinterface;

import java.util.HashMap;
import java.util.Map;

public class MapExampleTwo {

	public static void main(String[] args) {
		Map<Integer, String> map=new HashMap<Integer, String>();
		map.put(101, "apple");
		map.put(102, "orange");
		map.put(103, "orange");
		map.put(104, "banana");
		
		map.entrySet()
		.stream()
		.sorted(Map.Entry.comparingByKey())
		
		.forEach(System.out::println);
		
		

	}

}
