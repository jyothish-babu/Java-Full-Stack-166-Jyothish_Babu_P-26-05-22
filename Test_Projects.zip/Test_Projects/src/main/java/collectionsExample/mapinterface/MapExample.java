package collectionsExample.mapinterface;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapExample {  //old method

	public static void main(String[] args) {
		Map map=new HashMap<Integer, String>();
		map.put(101, "apple");
		map.put(102, "orange");
		map.put(103, "orange");
		map.put(104, "banana");
		
		//System.out.println(map);
		
		Set set=map.entrySet();
		Iterator itr=set.iterator();
		
		while(itr.hasNext()) {
			Map.Entry entry=(Map.Entry)itr.next();
			System.out.println(entry.getKey()+" "+entry.getValue());
		}

	}

}
