package collectionsExample.mapinterface;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class MapExampleDesc {

	public static void main(String[] args) {
		Map<Integer, String> map=new HashMap<Integer, String>();
		map.put(101, "apple");
		map.put(102, "orange");
		map.put(103, "orange");
		map.put(104, "banana");
		
		map.entrySet()
		.stream()
		.sorted(Map.Entry.comparingByKey(Comparator.reverseOrder()))
		.forEach(System.out::println);

	}

}
