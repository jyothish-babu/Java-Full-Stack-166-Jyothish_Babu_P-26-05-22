package collectionsExample.treeset;

import java.util.TreeSet;

public class TreeListThree {

	public static void main(String[] args) {
		TreeSet<String> ts=new TreeSet<String>();
		ts.add("A");
		ts.add("B");
		ts.add("C");
		ts.add("E");
		ts.add("F");
		
		System.out.println("initial set"+ts);
		System.out.println("reverse set"+ts.descendingSet());
		System.out.println("head set"+ts.headSet("C",true));
		System.out.println("sub set"+ts.subSet("A",false, "E",true));
		System.out.println("tailset"+ts.tailSet("C",false));
		
		
		
		System.out.println("head set"+ts.headSet("C"));
		System.out.println("sub set"+ts.subSet("A", "E"));
		System.out.println("tailset"+ts.tailSet("C"));

	}

}
