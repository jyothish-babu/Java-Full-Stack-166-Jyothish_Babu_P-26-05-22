package collectionsExample.treeset;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetOne {

	public static void main(String[] args) {
		TreeSet<String> ts=new TreeSet<String>();
		ts.add("apple");
		ts.add("orange");
		ts.add("mango");
		
		Iterator<String> itr=ts.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		Iterator<String> itr1=ts.descendingIterator();
		while(itr1.hasNext()) {
			System.out.println(itr1.next());
		}
		
		

	}

}
