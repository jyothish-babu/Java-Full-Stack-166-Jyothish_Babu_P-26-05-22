package collectionsExample.treeset;

import java.util.TreeSet;

import collectionsExample.hashset.BookHashSet;

public class TestBookTreeSet {

	public static void main(String[] args) {
		TreeSet<BookTreeSet> tset=new TreeSet<BookTreeSet>();
		
		BookTreeSet b=new BookTreeSet(101, "arun", "manu", "vinu", 5);
		BookTreeSet b1=new BookTreeSet(109, "ammu", "felix", "soman", 10);
		BookTreeSet b2=new BookTreeSet(107, "keshavan", "kannan", "vimal", 8);
		
		tset.add(b);
		tset.add(b1);
		tset.add(b2);
		
		for(BookTreeSet bt:tset) {
			System.out.println("id:"+bt.id+" name:"+bt.name+" author:"+bt.author+" publisher:"+bt.publisher+" quantity:"+bt.quantity);
		}

	}

}
