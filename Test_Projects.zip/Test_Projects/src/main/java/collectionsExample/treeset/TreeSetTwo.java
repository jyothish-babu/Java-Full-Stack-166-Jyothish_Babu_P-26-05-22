package collectionsExample.treeset;

import java.util.TreeSet;

public class TreeSetTwo {

	public static void main(String[] args) {
		TreeSet<Integer> ts=new TreeSet<Integer>();
		ts.add(45);
		ts.add(18);
		ts.add(59);
		ts.add(96);
		
		System.out.println(ts);
		System.out.println("first value"+ts.pollFirst());
		System.out.println("last value"+ts.pollLast());
		System.out.println(ts);
		
		

	}

}
