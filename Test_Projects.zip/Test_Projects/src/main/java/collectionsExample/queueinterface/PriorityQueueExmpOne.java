package collectionsExample.queueinterface;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueExmpOne {

	public static void main(String[] args) {
		Queue<String> queue=new PriorityQueue<String>();
		queue.add("apple");
		queue.add("orange");
		queue.add("grapes");
		queue.add("mango");
		
		System.out.println("head:"+queue.element());
		System.out.println("head:"+queue.peek());
		
		Iterator<String> itr=queue.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("after remove and poll");
		queue.remove();
		queue.poll();
		Iterator<String> itr1=queue.iterator();
		while(itr1.hasNext()) {
			System.out.println(itr1.next());
		}

	}

}
