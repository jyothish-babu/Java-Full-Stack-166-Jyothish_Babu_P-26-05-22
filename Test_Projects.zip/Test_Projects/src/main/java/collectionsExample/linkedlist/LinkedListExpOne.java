package collectionsExample.linkedlist;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListExpOne {

	public static void main(String[] args) {
		LinkedList<String> str=new LinkedList<String>();
		str.add("arun");
		str.add("anu");
		str.add("manu");
		Iterator<String> value=str.iterator();
		while(value.hasNext()) {
			System.out.println(value.next());
		}
	}

}
