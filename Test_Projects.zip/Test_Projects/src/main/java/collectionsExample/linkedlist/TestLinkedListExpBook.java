package collectionsExample.linkedlist;

import java.util.LinkedList;

public class TestLinkedListExpBook {

	public static void main(String[] args) {
		LinkedList<LinkedListExpBook> list=new LinkedList<LinkedListExpBook>();
		
		LinkedListExpBook b0=new LinkedListExpBook(101,"vinu","manu","ks",1001);
		LinkedListExpBook b1=new LinkedListExpBook(101,"vinu","manu","ks1",1022);
		LinkedListExpBook b2=new LinkedListExpBook(101,"vinu","manu","ks2",1055);
		
		list.add(b0);
		list.add(b1);
		list.add(b2);
		
		for(LinkedListExpBook b:list) {
			System.out.println("id:"+b.id +"name:"+b.name+"author:"+b.author+"publishe:"+b.publisher);
		}

	}

}
