package collectionsExample.linkedlist;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListExpDescIterator {

	public static void main(String[] args) {
		LinkedList<String> str=new LinkedList<String>();
		str.add("arun");
		str.add("vinu");
		str.add("athira");
		
		Iterator<String> value=str.descendingIterator();
		while(value.hasNext()) {
			System.out.println(value.next());
		}

	}

}
