package collectionsExample.linkedlist;

public class LinkedListExpBook {
	int id;
	String name,author,publisher;
	int quantity;
	public LinkedListExpBook(int id, String name, String author, String publisher, int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}
	
}
