package collectionsExample.linkedlist;

import java.util.LinkedList;

public class LinkedListExpTwo {

	public static void main(String[] args) {
		LinkedList<String> str=new LinkedList<String>();
		str.add("arun");
		str.add("anu");
		str.add("manu");
		System.out.println("before adding a value in index 1: "+str);
		str.add(1, "vinu");
		System.out.println("add vinu at 1: "+str);
		
		LinkedList<String> str1=new LinkedList<String>();
		str1.add("subin");
		str1.add("soman");
		str.addAll(str1);
		System.out.println("after addall method: "+str);
		
		LinkedList<String> str2=new LinkedList<String>();
		str2.add("felix");
		str.addAll(1, str2);
		System.out.println("add str2 @ index 1: "+str);
		
		str.addFirst("vinu");
		System.out.println("add first index: "+str);
		
		str.addLast("zyx");
		System.out.println("add last index: "+str);
		
		

	}

}
