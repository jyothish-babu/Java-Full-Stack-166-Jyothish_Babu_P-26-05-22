package collectionsExample.linkedlist;

import java.util.LinkedList;

public class LinkedListExpThree {

	public static void main(String[] args) {
		LinkedList<String> str=new LinkedList<String>();
		str.add("vinu");
		str.add("felix");
		str.add("soman");
		str.add("athira");
		System.out.println("list is: "+str);
		
		str.remove("vinu");
		System.out.println("removing vinu:"+str);
		str.remove(0);
		System.out.println("remove from 0th idenx: "+str);
		
		LinkedList<String> str1=new LinkedList<String>();
		str1.add("cat");
		str1.add("dog");
		str1.add("birds");
		str1.add("arathy");
		str1.add("vineetha");
		str.addAll(str1);
		System.out.println("after adding str1 to str: "+str);
//		str.removeAll(str1);
//		System.out.println("after removing str1 from str: "+str);
		
		str.removeLast();
		System.out.println(str);
		
		
		
		str.removeFirstOccurrence("soman");
		System.out.println(str);
		
		str.removeLastOccurrence("birds");
		System.out.println(str);
		
		
		

	}

}
