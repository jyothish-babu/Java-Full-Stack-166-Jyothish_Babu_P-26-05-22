package collectionsExample.hashset;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetOne {  //HashSet doesn't allow duplicate elements

	public static void main(String[] args) {
		HashSet<String> set=new HashSet<String>();
		set.add("soman");
		set.add("felix");
		set.add("subin");
		set.add("adhwide");
		set.add("subin");
		
		Iterator<String> itr=set.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
