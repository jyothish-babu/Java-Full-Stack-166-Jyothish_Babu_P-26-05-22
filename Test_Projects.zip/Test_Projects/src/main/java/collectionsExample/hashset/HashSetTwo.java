package collectionsExample.hashset;

import java.util.HashSet;

public class HashSetTwo {

	public static void main(String[] args) {
		HashSet<String> set=new HashSet<String>();
		set.add("soman");
		set.add("felix");
		set.add("subin");
		set.add("adhwide");
		set.add("subin");
		
		set.remove("soman");
		System.out.println("after removing a string"+set);
		
		HashSet<String> set2=new HashSet<String>();
		set2.add("mango");
		set2.add("apple");
		set.addAll(set2);
		System.out.println("after adding set2 in set"+set);
		
		set.removeAll(set2);
		System.out.println("after removeing set2 from set"+set);
		
		//removing element basic of specified condition
		set.removeIf(str->str.contains("felix"));
		System.out.println(set);
		
		set.clear();
		System.out.println(set); //clear all element from set
	}

}
