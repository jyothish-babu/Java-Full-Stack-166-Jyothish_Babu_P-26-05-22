package collectionsExample.hashset;

public class BookHashSet {
	int id;
	String name,author,publisher;
	int quantity;
	public BookHashSet(int id, String name, String author, String publisher, int quantity) {
		super();
		this.id = id;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.quantity = quantity;
	}
	

}
