package collectionsExample.hashset;

import java.util.HashSet;

public class TestBookHashSet {

	public static void main(String[] args) {
		HashSet<BookHashSet> set5=new HashSet<BookHashSet>();
		
		BookHashSet b=new BookHashSet(101, "arun", "manu", "vinu", 5);
		BookHashSet b1=new BookHashSet(101, "ammu", "felix", "soman", 10);
		BookHashSet b2=new BookHashSet(101, "keshavan", "kannan", "vimal", 8);
		
		set5.add(b);
		set5.add(b1);
		set5.add(b2);
		
		for(BookHashSet s:set5) {
			System.out.println("id:"+s.id+", name:"+s.name+", author:"+s.author+", publisher:"+s.publisher+", quantity:"+s.quantity);
		}
		

	}

}
