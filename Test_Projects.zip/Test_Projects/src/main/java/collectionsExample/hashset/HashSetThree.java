package collectionsExample.hashset;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class HashSetThree {

	public static void main(String[] args) {
		ArrayList<String> listArray=new ArrayList<String>();
		listArray.add("apple");
		listArray.add("mango");
		
		HashSet<String> hs=new HashSet(listArray);
		hs.add("cat");
		
		Iterator<String> itr=hs.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
