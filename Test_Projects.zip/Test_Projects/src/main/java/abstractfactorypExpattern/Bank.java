package abstractfactorypExpattern;

public interface Bank {
	String getBankName();

}
