package polymorphisms.methodoverloading;

public class MatchingArg {
	void sun(int a,int b) {
		
	}

}
