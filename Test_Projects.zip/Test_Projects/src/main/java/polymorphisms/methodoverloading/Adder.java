package polymorphisms.methodoverloading;

public class Adder {
	static int add(int a,int b) {
		return a+b;
	}
	
	static int add(int a,int b,int c) {
		return a+b+c;
	}
	
	static double add(double a,int b,double c,int d) {
		double e=a+b+c+d;
		return e;
		
	}

}
