package polymorphisms.methodoverloading;

public class AdderOne {
	static int add(int a,int b) {
		return a+b;
	}
	
	
	void sum(int a,int b) {
		System.out.println(a+b);
	}
	void sum(int a,int b,int c) {
		System.out.println(a+b+c);
	}

}
