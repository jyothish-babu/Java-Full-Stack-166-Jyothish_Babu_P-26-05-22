package polymorphisms.methodoverloading;

public class TestAdderOne {

	public static void main(String[] args) {
		AdderOne ad=new AdderOne();
		ad.sum(45, 40);
		ad.sum(20, 40, 80);
		
		AdderOne.add(55, 45);
		System.out.println(Adder.add(40, 40));
		
		

	}

}
