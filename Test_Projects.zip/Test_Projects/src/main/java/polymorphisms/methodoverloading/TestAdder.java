package polymorphisms.methodoverloading;

public class TestAdder {

	public static void main(String[] args) {
		System.out.println(Adder.add(2,5));
		System.out.println(Adder.add(5, 4, 9));
		
		System.out.println(Adder.add(6.2, 4, 7.3, 3));

	}

}
