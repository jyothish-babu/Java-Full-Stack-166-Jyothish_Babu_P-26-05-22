package polymorphisms;

public class Splender extends Bike{
	void run() {
		super.run();
		System.out.println("running fast");
	}

}
