package polymorphisms;

public class TestBike {

	public static void main(String[] args) {
		Splender sp=new Splender();
		sp.run();

	}

}
