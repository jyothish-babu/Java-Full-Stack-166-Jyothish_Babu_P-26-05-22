package polymorphisms;

public class AnimalOne {    //runtime polymorphism, dinamic binding
	void eat() {
		System.out.println("foods");
	}

}
