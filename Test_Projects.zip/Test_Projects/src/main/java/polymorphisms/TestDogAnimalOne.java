package polymorphisms;

public class TestDogAnimalOne {

	public static void main(String[] args) {
		AnimalOne a1=new DogAnimalOne();
		a1.eat();

	}

}
