package polymorphisms;

public class DogAnimalOne extends AnimalOne {
	void eat() {
		super.eat();
		System.out.println("meet");
	}

}
