package polymorphisms.methodoverriding;

public class TestBank {

	public static void main(String[] args) {
		Bank b=new Icici();
		System.out.println(b.rateOfInterest());
		b=new Axis();
		System.out.println(b.rateOfInterest());

	}

}
