package polymorphisms.methodoverriding;

public class Axis extends Bank{
	int rateOfInterest() {
		return 7;
	}

}
