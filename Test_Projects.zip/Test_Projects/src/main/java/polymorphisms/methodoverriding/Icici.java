package polymorphisms.methodoverriding;

public class Icici extends Bank {
	int rateOfInterest() {
		return 6;
	}

}
