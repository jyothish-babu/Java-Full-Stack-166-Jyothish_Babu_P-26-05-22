package polymorphisms.methodoverriding;

public class Bank {
	int rateOfInterest() {
		return 0;
	}

}
