package oopsthisexample;

public class TestQuestionThisOne {

	public static void main(String[] args) {
		QuestionThisOne s1=new QuestionThisOne(10,"arun",5000);
		QuestionThisOne s2=new QuestionThisOne(11,"ammu",5000);
		s1.display();
		s2.display();
		

	}

}
