package oopsthisexample;

public class QuestionThisOne {
	int rollNo;
	String name;
	int fee;
	
	QuestionThisOne(int rollNo,String name,int fee){
		this.rollNo=rollNo;
		this.name=name;
		this.fee=fee;
	}
	void display() {
		System.out.println(rollNo+""+name+""+fee);
	}
	

}
