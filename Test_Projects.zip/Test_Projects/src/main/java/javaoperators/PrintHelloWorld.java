package javaoperators;

public class PrintHelloWorld {

	public static void main(String[] args) {
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
//		System.out.println("helloe World");
		for(int i=10;i<=10;i++) {
			System.out.println("Hello World");
			
			System.out.println(i);
			
			System.out.println(i*2);
			
			
//			for(;;) {
//				System.out.println("Hello World");
		}
		
	}

}
