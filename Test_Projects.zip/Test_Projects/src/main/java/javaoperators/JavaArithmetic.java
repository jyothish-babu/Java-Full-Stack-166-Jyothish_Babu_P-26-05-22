package javaoperators;

public class JavaArithmetic {

	public static void main(String[] args) {
		int a=10;
		int b=5;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a/b);
		System.out.println(a*b);
		System.out.println(a%b);
		System.out.println();
		
		System.out.println(10*10/5+3-1*4/2);
		System.out.println();
		
		
		System.out.println(10<<2); //10*2^2
		System.out.println(10<<3); //10*2^3  // left shift operators
		System.out.println(10<<4); //10*2^4
		System.out.println();
		
		System.out.println(10>>3); //10/2^3
		System.out.println(20>>4); //20/2^4
		
		
		

	}

}
