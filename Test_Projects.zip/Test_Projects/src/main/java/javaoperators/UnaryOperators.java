package javaoperators;

public class UnaryOperators {

	public static void main(String[] args) {
		int a=10;
		int b=10;
		int c=-10;
		boolean d=true;
		boolean e=false;
		
		System.out.println(a++);
		System.out.println(++a);
		System.out.println(a--);
		System.out.println(--a);
		System.out.println();
		
		
		System.out.println(a++ + ++a);
		System.out.println(b++ + b++);
		System.out.println();
		
		System.out.println(~a);
		System.out.println(~c);
		System.out.println(!d);
		System.out.println(!e);
		
		
		
		
		
		
		
		

	}

}
